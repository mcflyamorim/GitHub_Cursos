/*
  PASS Summit 2026
  Author: Fabiano Amorim | fabianonevesamorim@hotmail.com
*/

/*
  Run this on amorim-PF5ZTLCK\SQL2016
  Run this on amorim-PF5ZTLCK\SQL2016
  Run this on amorim-PF5ZTLCK\SQL2016
*/

/* Step 1 */
/* Create a database and a login for with db_onwer on the DB */
USE master
GO
IF DB_ID('DbAppDemo1') IS NOT NULL
BEGIN
  ALTER DATABASE DbAppDemo1 SET SINGLE_USER WITH ROLLBACK IMMEDIATE
  DROP DATABASE DbAppDemo1
END
CREATE DATABASE DbAppDemo1
GO
IF SUSER_SID('AppDemo1') IS NOT NULL
  DROP LOGIN AppDemo1
GO
CREATE LOGIN AppDemo1 WITH PASSWORD = '102030', CHECK_POLICY = OFF
GO
USE DbAppDemo1
GO
DROP USER IF EXISTS AppDemo1
GO
CREATE USER AppDemo1 FOR LOGIN AppDemo1
GO
ALTER ROLE db_owner ADD MEMBER AppDemo1
GO
IF SUSER_SID('*** Demo 1 - I Should Not Be Here I''m a SysAdmin now ***') IS NOT NULL
  DROP LOGIN [*** Demo 1 - I Should Not Be Here I'm a SysAdmin now ***]
GO