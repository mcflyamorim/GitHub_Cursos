/*
  PASS Summit 2026
  Author: Fabiano Amorim | fabianonevesamorim@hotmail.com
*/

/* Step 1 */
/* Create a database and a login for with db_onwer on the DB */
USE master
GO
IF DB_ID('DbAppDemo1') IS NOT NULL
BEGIN
  ALTER DATABASE DbAppDemo1 SET SINGLE_USER WITH ROLLBACK IMMEDIATE
  DROP DATABASE DbAppDemo1
END
CREATE DATABASE DbAppDemo1
GO
IF SUSER_SID('AppDemo1') IS NOT NULL
  DROP LOGIN AppDemo1
GO
CREATE LOGIN AppDemo1 WITH PASSWORD = '102030', CHECK_POLICY = OFF
GO
USE DbAppDemo1
GO
DROP USER IF EXISTS AppDemo1
GO
CREATE USER AppDemo1 FOR LOGIN AppDemo1
GO
ALTER ROLE db_ddladmin ADD MEMBER AppDemo1
GO
IF SUSER_SID('*** Demo 1 - I Should Not Be Here I''m a SysAdmin now ***') IS NOT NULL
  DROP LOGIN [*** Demo 1 - I Should Not Be Here I'm a SysAdmin now ***]
GO
USE DbAppDemo1
GO
IF OBJECT_ID('TabTestUpdateStats') IS NOT NULL
  DROP TABLE TabTestUpdateStats
GO
SELECT TOP 10000 /*1mi rows*/
       ISNULL(ROW_NUMBER() OVER(ORDER BY (SELECT 1)),0) AS CustomerID, 
       SUBSTRING(CONVERT(VARCHAR(250),NEWID()),1,8) AS ContactName, 
       CONVERT(VARCHAR(250), NEWID()) AS Col1,
       CONVERT(VARCHAR(250), NEWID()) AS Col2,
       CONVERT(VARCHAR(250), NEWID()) AS Col3,
       CONVERT(VARCHAR(250), NEWID()) AS Col4,
       CONVERT(VARCHAR(250), NEWID()) AS Col5
  INTO TabTestUpdateStats
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
OPTION (MAXDOP 8)
GO
ALTER TABLE TabTestUpdateStats ADD CONSTRAINT xpk_TabTestUpdateStats PRIMARY KEY(CustomerID)
GO
/* This will create a stat for each column */
SELECT DISTINCT Col1,
                Col2,
                Col3,
                Col4,
                Col5
FROM TabTestUpdateStats
GO

/* 
  Step 2 - Create a job to run update statistics using Ola's maintenance script.

  By default, when you create a job in SQL Server Agent and you are sysadmin, 
  the job will execute in the context of the service account for SQL Server Agent, 
  which also is a member of the sysadmin role.
*/
IF EXISTS(SELECT * FROM msdb.dbo.sysjobs_view WHERE name = N'Maintenance - UpdateStats')
  EXEC msdb.dbo.sp_delete_job @job_name = N'Maintenance - UpdateStats'
GO
DECLARE @jobId BINARY(16)
EXEC msdb.dbo.sp_add_job @job_name = N'Maintenance - UpdateStats', 
		@enabled = 1, 
		@description = N'Source: https://ola.hallengren.com', 
		@owner_login_name = N'amorim-PF5ZTLCK\fabia',
  @job_id = @jobId OUTPUT

EXEC msdb.dbo.sp_add_jobstep @job_id = @jobId, @step_name = N'Maintenance - UpdateStats', 
		@step_id = 1, 
  @subsystem = N'TSQL', 
		@command = N'EXECUTE dbo.IndexOptimize @Databases = ''USER_DATABASES'', @FragmentationLow = NULL, @FragmentationMedium = NULL, @FragmentationHigh = NULL, @UpdateStatistics = ''ALL''',
		@database_name = N'master';

EXEC msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
GO