/*
  PASS Summit 2026
  Author: Fabiano Amorim | fabianonevesamorim@hotmail.com
*/

/*
  Step 1 - Create Login with min permission required
*/
USE [master];
GO
IF SUSER_SID('AppDemo2') IS NOT NULL
  DROP LOGIN AppDemo2
GO
CREATE LOGIN AppDemo2 WITH PASSWORD=N'102030', CHECK_POLICY=OFF;
GO
USE [tempdb];
GO
IF USER_ID('AppDemo2') IS NOT NULL
  DROP USER AppDemo2;
GO
CREATE USER AppDemo2 FOR LOGIN AppDemo2;
GO
GRANT CONTROL TO AppDemo2;
GO
IF SUSER_SID('*** Demo 2 - I Should Not Be Here I''m a SysAdmin now ***') IS NOT NULL
  DROP LOGIN [*** Demo 2 - I Should Not Be Here I'm a SysAdmin now ***]
GO