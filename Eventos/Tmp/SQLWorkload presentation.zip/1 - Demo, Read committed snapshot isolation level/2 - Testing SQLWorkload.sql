-- Connect on VM4\SQL2012
USE master
GO
ALTER DATABASE Northwind SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE Northwind SET READ_COMMITTED_SNAPSHOT OFF WITH ROLLBACK IMMEDIATE
GO
USE Northwind
GO
IF OBJECT_ID('OrdersBig') IS NOT NULL
  DROP TABLE OrdersBig
GO
SELECT TOP 5000000
       IDENTITY(Int, 1,1) AS OrderID,
       0 + ABS(CHECKSUM(NEWID())) % (100-0) AS CustomerID,
       CONVERT(Date, GETDATE() - (CheckSUM(NEWID()) / 1000000)) AS OrderDate,
       ISNULL(ABS(CONVERT(Numeric(18,2), (CheckSUM(NEWID()) / 1000000.5))),0) AS Value
  INTO OrdersBig
  FROM Orders A
 CROSS JOIN Orders B CROSS JOIN Orders C CROSS JOIN Orders D
GO
ALTER TABLE OrdersBig ADD CONSTRAINT xpk_OrdersBig PRIMARY KEY(OrderID) WITH(DATA_COMPRESSION=PAGE)
GO
CREATE INDEX ixCustomerID ON OrdersBig (CustomerID) INCLUDE(Value) WITH(DATA_COMPRESSION=PAGE)
GO
CHECKPOINT; DBCC DROPCLEANBUFFERS(); DBCC FREEPROCCACHE()
GO

-- Update a few rows on table OrdersBig
UPDATE TOP (10000) OrdersBig WITH(ROWLOCK)
SET Value = ISNULL(ABS(CONVERT(Numeric(18,2), (CheckSUM(NEWID()) / 1000000.5))),0)
WHERE CustomerID = 0 + ABS(CHECKSUM(NEWID())) % (100-0);
GO

-- Will be blocked by update
SELECT SUM(Value) AS Val FROM OrdersBig
WHERE CustomerID = 0 + ABS(CHECKSUM(NEWID())) % (100-0);
GO

-- Remove existing SQLLite file
-- DEL "D:\Fabiano\Trabalho\Pythian\Customers\Statpro_Confluence\SQLWorkload presentation\1 - Demo, Read committed snapshot isolation level\SqlWorkload.sqlite"

-- Record workload
-- "C:\Program Files\WorkloadTools\SqlWorkload.exe" --File "D:\Fabiano\Trabalho\Pythian\Customers\Statpro_Confluence\SQLWorkload presentation\1 - Demo, Read committed snapshot isolation level\Capture workload.json"
/*
{
  "Controller": {
    "Listener": {
      "__type": "ExtendedEventsWorkloadListener",
      "ConnectionInfo": {
        "ServerName": "VM4\\SQL2012",
        "UserName": "sa",
        "Password": "@bc12345"
      }
    },
    "Consumers": [
      {
        "__type": "WorkloadFileWriterConsumer",
        "OutputFile": "D:\\Fabiano\\Trabalho\\Pythian\\Customers\\Statpro_Confluence\\SQLWorkload presentation\\1 - Demo, Read committed snapshot isolation level\\SqlWorkload.sqlite"
      }
    ]
  }
}
*/

-- Start SQLQueryStress to simulate workload
-- Workload takes average of 5 minutes to run
-- While workload is running, check sp_whoisactive
USE master
GO
sp_whoisactive
GO
SELECT 
       SUM(user_object_reserved_page_count) * 8 AS usr_obj_kb,
       SUM(internal_object_reserved_page_count) * 8 AS internal_obj_kb,
       SUM(version_store_reserved_page_count) * 8 AS version_store_kb,
       SUM(unallocated_extent_page_count) * 8 AS freespace_kb,
       SUM(mixed_extent_page_count) * 8 AS mixedextent_kb
FROM tempdb.sys.dm_db_file_space_usage;
GO

-- Prepare replay environment
BACKUP DATABASE [Northwind] 
TO  DISK = N'E:\Northwind.bak' 
WITH  COPY_ONLY, NOFORMAT, INIT,  NAME = N'Northwind-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10, COMPRESSION
GO

-- Restore DB on replay env.
-- Log on VM3\SQL2019 and restore the DB 
USE [master]
RESTORE DATABASE [Northwind] FROM DISK = N'\\vm4\e$\Northwind.bak' WITH  FILE = 1,  
MOVE N'Northwind' TO N'C:\DBs\northwnd.mdf',  
MOVE N'Northwind_log' TO N'C:\DBs\northwnd.ldf',  NOUNLOAD,  STATS = 5, REPLACE
GO

-- Log on VM3\SQL2019 and enable snapshot isolation 
use master
GO
ALTER DATABASE Northwind SET ALLOW_SNAPSHOT_ISOLATION ON 
GO
ALTER DATABASE Northwind SET READ_COMMITTED_SNAPSHOT ON WITH ROLLBACK IMMEDIATE
GO


-- Replay workload on both instances
/*
"C:\Program Files\WorkloadTools\SqlWorkload.exe" --File "D:\Fabiano\Trabalho\Pythian\Customers\Statpro_Confluence\SQLWorkload presentation\1 - Demo, Read committed snapshot isolation level\Replay workload on VM3.json"
"C:\Program Files\WorkloadTools\SqlWorkload.exe" --File "D:\Fabiano\Trabalho\Pythian\Customers\Statpro_Confluence\SQLWorkload presentation\1 - Demo, Read committed snapshot isolation level\Replay workload on VM4.json"
*/

-- Check results on SQL Monitor, sp_whoisactive and dm_db_file_space_usage
-- Notice version store usage on tempdb and no more selects blocked by update

-- While workload is running, check sp_whoisactive
USE master
GO
sp_whoisactive
GO
SELECT 
       SUM(user_object_reserved_page_count) * 8 AS usr_obj_kb,
       SUM(internal_object_reserved_page_count) * 8 AS internal_obj_kb,
       SUM(version_store_reserved_page_count) * 8 AS version_store_kb,
       SUM(unallocated_extent_page_count) * 8 AS freespace_kb,
       SUM(mixed_extent_page_count) * 8 AS mixedextent_kb
FROM tempdb.sys.dm_db_file_space_usage;
GO


-- Some usefull scripts
/*
-- To check BackupFinishDate
RESTORE HEADERONLY FROM DISK = 'C:\backupfile.bak'
*/

/*
USE master
GO
sp_whoisactive
GO
SELECT 
       SUM(user_object_reserved_page_count) * 8 AS usr_obj_kb,
       SUM(internal_object_reserved_page_count) * 8 AS internal_obj_kb,
       SUM(version_store_reserved_page_count) * 8 AS version_store_kb,
       SUM(unallocated_extent_page_count) * 8 AS freespace_kb,
       SUM(mixed_extent_page_count) * 8 AS mixedextent_kb
FROM tempdb.sys.dm_db_file_space_usage;
GO
*/

/*


-- Clear Wait Stats with this command
-- DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);

-- Isolate top waits for server instance since last restart or wait statistics clear  (Query 39) (Top Waits)
WITH [Waits] 
AS (SELECT wait_type, wait_time_ms/ 1000.0 AS [WaitS],
          (wait_time_ms - signal_wait_time_ms) / 1000.0 AS [ResourceS],
           signal_wait_time_ms / 1000.0 AS [SignalS],
           waiting_tasks_count AS [WaitCount],
           100.0 *  wait_time_ms / SUM (wait_time_ms) OVER() AS [Percentage],
           ROW_NUMBER() OVER(ORDER BY wait_time_ms DESC) AS [RowNum]
    FROM sys.dm_os_wait_stats WITH (NOLOCK)
    WHERE [wait_type] NOT IN (
        N'BROKER_EVENTHANDLER', N'BROKER_RECEIVE_WAITFOR', N'BROKER_TASK_STOP',
		N'BROKER_TO_FLUSH', N'BROKER_TRANSMITTER', N'CHECKPOINT_QUEUE',
        N'CHKPT', N'CLR_AUTO_EVENT', N'CLR_MANUAL_EVENT', N'CLR_SEMAPHORE', N'CXCONSUMER',
        N'DBMIRROR_DBM_EVENT', N'DBMIRROR_EVENTS_QUEUE', N'DBMIRROR_WORKER_QUEUE',
		N'DBMIRRORING_CMD', N'DIRTY_PAGE_POLL', N'DISPATCHER_QUEUE_SEMAPHORE',
        N'EXECSYNC', N'FSAGENT', N'FT_IFTS_SCHEDULER_IDLE_WAIT', N'FT_IFTSHC_MUTEX',
        N'HADR_CLUSAPI_CALL', N'HADR_FILESTREAM_IOMGR_IOCOMPLETION', N'HADR_LOGCAPTURE_WAIT', 
		N'HADR_NOTIFICATION_DEQUEUE', N'HADR_TIMER_TASK', N'HADR_WORK_QUEUE',
        N'KSOURCE_WAKEUP', N'LAZYWRITER_SLEEP', N'LOGMGR_QUEUE', 
		N'MEMORY_ALLOCATION_EXT', N'ONDEMAND_TASK_QUEUE',
		N'PARALLEL_REDO_DRAIN_WORKER', N'PARALLEL_REDO_LOG_CACHE', N'PARALLEL_REDO_TRAN_LIST',
		N'PARALLEL_REDO_WORKER_SYNC', N'PARALLEL_REDO_WORKER_WAIT_WORK',
		N'PREEMPTIVE_HADR_LEASE_MECHANISM', N'PREEMPTIVE_SP_SERVER_DIAGNOSTICS',
		N'PREEMPTIVE_OS_LIBRARYOPS', N'PREEMPTIVE_OS_COMOPS', N'PREEMPTIVE_OS_CRYPTOPS',
		N'PREEMPTIVE_OS_PIPEOPS', N'PREEMPTIVE_OS_AUTHENTICATIONOPS',
		N'PREEMPTIVE_OS_GENERICOPS', N'PREEMPTIVE_OS_VERIFYTRUST',
		N'PREEMPTIVE_OS_FILEOPS', N'PREEMPTIVE_OS_DEVICEOPS', N'PREEMPTIVE_OS_QUERYREGISTRY',
		N'PREEMPTIVE_OS_WRITEFILE', N'PREEMPTIVE_OS_WRITEFILEGATHER',
		N'PREEMPTIVE_XE_CALLBACKEXECUTE', N'PREEMPTIVE_XE_DISPATCHER',
		N'PREEMPTIVE_XE_GETTARGETSTATE', N'PREEMPTIVE_XE_SESSIONCOMMIT',
		N'PREEMPTIVE_XE_TARGETINIT', N'PREEMPTIVE_XE_TARGETFINALIZE',
        N'PWAIT_ALL_COMPONENTS_INITIALIZED', N'PWAIT_DIRECTLOGCONSUMER_GETNEXT',
		N'PWAIT_EXTENSIBILITY_CLEANUP_TASK',
		N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP', N'QDS_ASYNC_QUEUE',
        N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP', N'REQUEST_FOR_DEADLOCK_SEARCH',
		N'RESOURCE_QUEUE', N'SERVER_IDLE_CHECK', N'SLEEP_BPOOL_FLUSH', N'SLEEP_DBSTARTUP',
		N'SLEEP_DCOMSTARTUP', N'SLEEP_MASTERDBREADY', N'SLEEP_MASTERMDREADY',
        N'SLEEP_MASTERUPGRADED', N'SLEEP_MSDBSTARTUP', N'SLEEP_SYSTEMTASK', N'SLEEP_TASK',
        N'SLEEP_TEMPDBSTARTUP', N'SNI_HTTP_ACCEPT', N'SOS_WORK_DISPATCHER',
		N'SP_SERVER_DIAGNOSTICS_SLEEP',
		N'SQLTRACE_BUFFER_FLUSH', N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP', N'SQLTRACE_WAIT_ENTRIES',
		N'STARTUP_DEPENDENCY_MANAGER',
		N'WAIT_FOR_RESULTS', N'WAITFOR', N'WAITFOR_TASKSHUTDOWN', N'WAIT_XTP_HOST_WAIT',
		N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG', N'WAIT_XTP_CKPT_CLOSE', N'WAIT_XTP_RECOVERY',
		N'XE_BUFFERMGR_ALLPROCESSED_EVENT', N'XE_DISPATCHER_JOIN',
        N'XE_DISPATCHER_WAIT', N'XE_LIVE_TARGET_TVF', N'XE_TIMER_EVENT')
    AND waiting_tasks_count > 0)
SELECT
    MAX (W1.wait_type) AS [WaitType],
	CAST (MAX (W1.Percentage) AS DECIMAL (5,2)) AS [Wait Percentage],
	CAST ((MAX (W1.WaitS) / MAX (W1.WaitCount)) AS DECIMAL (16,4)) AS [AvgWait_Sec],
    CAST ((MAX (W1.ResourceS) / MAX (W1.WaitCount)) AS DECIMAL (16,4)) AS [AvgRes_Sec],
    CAST ((MAX (W1.SignalS) / MAX (W1.WaitCount)) AS DECIMAL (16,4)) AS [AvgSig_Sec], 
    CAST (MAX (W1.WaitS) AS DECIMAL (16,2)) AS [Wait_Sec],
    CAST (MAX (W1.ResourceS) AS DECIMAL (16,2)) AS [Resource_Sec],
    CAST (MAX (W1.SignalS) AS DECIMAL (16,2)) AS [Signal_Sec],
    MAX (W1.WaitCount) AS [Wait Count],
	CAST (N'https://www.sqlskills.com/help/waits/' + W1.wait_type AS XML) AS [Help/Info URL]
FROM Waits AS W1
INNER JOIN Waits AS W2
ON W2.RowNum <= W1.RowNum
GROUP BY W1.RowNum, W1.wait_type
HAVING SUM (W2.Percentage) - MAX (W1.Percentage) < 99 -- percentage threshold
OPTION (RECOMPILE);
*/

