-- Connect on fabianoamorimtest1.database.windows.net | master
ALTER DATABASE Northwind SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE Northwind SET READ_COMMITTED_SNAPSHOT OFF WITH ROLLBACK IMMEDIATE
GO

-- Connect on fabianoamorimtest1.database.windows.net | Northwind
IF OBJECT_ID('OrdersBig') IS NOT NULL
  DROP TABLE OrdersBig
GO
SELECT TOP 5000000
       IDENTITY(Int, 1,1) AS OrderID,
       0 + ABS(CHECKSUM(NEWID())) % (100-0) AS CustomerID,
       CONVERT(Date, GETDATE() - (CheckSUM(NEWID()) / 1000000)) AS OrderDate,
       ISNULL(ABS(CONVERT(Numeric(18,2), (CheckSUM(NEWID()) / 1000000.5))),0) AS Value
  INTO OrdersBig
  FROM Orders A
 CROSS JOIN Orders B CROSS JOIN Orders C CROSS JOIN Orders D
GO
ALTER TABLE OrdersBig ADD CONSTRAINT xpk_OrdersBig PRIMARY KEY(OrderID) WITH(DATA_COMPRESSION=PAGE)
GO
CREATE INDEX ixCustomerID ON OrdersBig (CustomerID)
INCLUDE(OrderDate, Value)
GO

-- Test query
SELECT TOP (0 + ABS(CHECKSUM(NEWID())) % (5000-0)) * FROM OrdersBig WHERE CustomerID = 0 + ABS(CHECKSUM(NEWID())) % (100-0);
GO




-- Record and realtime replay workload
-- "C:\Program Files\WorkloadTools\SqlWorkload.exe" --File "D:\Fabiano\Trabalho\Pythian\Customers\Statpro_Confluence\SQLWorkload presentation\2 - Demo, Realtime replay on AzureSQLDB and SQLMonitor\Capture and realtime replay workload.json"
-- Capture analysis data from replay server
-- "C:\Program Files\WorkloadTools\SqlWorkload.exe" --File "D:\Fabiano\Trabalho\Pythian\Customers\Statpro_Confluence\SQLWorkload presentation\2 - Demo, Realtime replay on AzureSQLDB and SQLMonitor\Capture and realtime replay workload - Replay.json"


/*
EXEC sp_WhoIsActive
GO

-- Verifica se tem app com MARS habilitado
SELECT conn.session_id,
       sess.program_name,
       sess.host_name,
       sess.client_interface_name,
       sess.login_name,
       sess.status,
       conn.net_transport,
       conn.protocol_version,
       conn.net_packet_size,
       sess.row_count,
       wait.wait_type,
       wait.wait_duration_ms,
       wait.resource_description,
       conn.num_reads,
       conn.num_writes,
       sess.login_time,
       conn.connection_id,
       conn.parent_connection_id,
       conn.most_recent_sql_handle
FROM sys.dm_exec_connections conn
    JOIN sys.dm_exec_sessions sess
        ON sess.session_id = conn.session_id
    LEFT OUTER JOIN sys.dm_os_waiting_tasks wait
        ON wait.session_id = conn.session_id
WHERE EXISTS
      (
          SELECT *
          FROM sys.dm_exec_connections b
          WHERE b.net_transport = 'Session' -- Se tiver alguma conex�o com MARS, net_transport vai ser = "Session"
          AND conn.session_id = b.session_id
      ) 
      AND status <> 'sleeping'
ORDER BY conn.session_id;
GO
*/