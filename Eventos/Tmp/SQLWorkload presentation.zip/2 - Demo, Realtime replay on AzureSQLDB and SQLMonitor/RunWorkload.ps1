function StressTSQL
{
param(
		        [Parameter(Position=1,mandatory=$true)][string] $query,
		        [Parameter(Position=2,mandatory=$true)][int] $iterations,
				[Parameter(Position=3,mandatory=$true)][String] $threads,
				[Parameter(Position=4,mandatory=$true)][String] $dbname,
				[Parameter(Position=5,mandatory=$true)][String] $user,
				[Parameter(Position=6,mandatory=$true)][String] $password,
				[Parameter(Position=7,mandatory=$true)][String] $serverinstance,
				[Parameter(Position=8,mandatory=$true)][int] $msdelay,
                [Parameter(Position=9,mandatory=$true)][int] $useMARS
		    )
	$block = {
				param(
				        [Parameter(Position=1,mandatory=$true)][string] $query,
				        [Parameter(Position=2,mandatory=$true)][int] $iterations,
						[Parameter(Position=3,mandatory=$true)][String] $dbname,
						[Parameter(Position=4,mandatory=$true)][String] $user,
						[Parameter(Position=5,mandatory=$true)][String] $password,
						[Parameter(Position=6,mandatory=$true)][String] $serverinstance,
						[Parameter(Position=7,mandatory=$true)][int] $msdelay,
                        [Parameter(Position=8,mandatory=$true)][int] $useMARS
				    )

				$i = 1
                if ($useMARS -eq 1){
                    $conn = New-Object System.Data.SqlClient.SqlConnection("Server=$serverinstance;Database=$dbname;User ID=$user;Password=$password;Trusted_Connection=False;Connect Timeout=10;MultipleActiveResultSets=True")    
                }
                else {
                    $conn = New-Object System.Data.SqlClient.SqlConnection("Server=$serverinstance;Database=$dbname;User ID=$user;Password=$password;Trusted_Connection=False;Connect Timeout=10")    
                }
				do
				{
					$SqlCommand1 = New-Object System.Data.SqlClient.SqlCommand ($query, $conn)
                    $SqlDataAdapter1 = New-Object System.Data.SqlClient.SqlDataAdapter $SqlCommand1
                    $DataSet1 = New-Object System.Data.DataSet
                    $SqlDataAdapter1.Fill($DataSet1) | Out-Null
					Start-Sleep -Milliseconds $msdelay #Delay to give server some breath
					$i++
				} While ($i -le $iterations)
                $DataSet1.Dispose()
                $conn.Dispose()
			}

	$thread_array = 0..($threads - 1)
	foreach  ($thread in $thread_array)
	{
		Start-ThreadJob -ThrottleLimit 50 -Scriptblock $Block -ArgumentList $query, $iterations, $db, $user, $password, $ServerInstance, $msdelay, $useMARS | Out-Null
	}
}

if (-not (Get-Module -ListAvailable -Name ThreadJob))
{
	Install-Module -Name ThreadJob -Force
}

if (-not (Get-Module -ListAvailable -Name Invoke-SqlCmd2))
{
	Install-Module -Name Invoke-SqlCmd2 -Force
}

$ServerInstance = "dellfabiano\sql2019"
$db = 'Northwind'
$user = "sa"
$password = '@bc12345'

Clear-Host

# Stop and remove all running jobs...
try{get-job | remove-job -force}catch{}

$Query = "SELECT TOP (0 + ABS(CHECKSUM(NEWID())) % (20000-0)) * FROM OrdersBig WHERE CustomerID = 0 + ABS(CHECKSUM(NEWID())) % (100-0);"

StressTSQL -Query $Query -Iterations 500000 -Threads 40 -DB $db -User $user -Password $password -ServerInstance $ServerInstance -msdelay 5 -useMARS 0

Get-Job | Format-Table

Measure-Command { Get-Job | Wait-Job } 

Get-Job | Format-Table
