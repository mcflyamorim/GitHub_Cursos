USE Northwind
GO
DBCC SHOW_STATISTICS (OrdersBig, ixEmployeeID) WITH STAT_HEADER
GO
DECLARE @StatsName sysname = 'ixEmployeeID', 
        @TableName sysname = 'OrdersBig',
        @height INT = 20

IF OBJECT_ID('tempdb.dbo.#tmp_seq') IS NOT NULL
  DROP TABLE #tmp_seq;

CREATE TABLE #tmp_seq
(
   vSeq INT PRIMARY KEY
)
;WITH cte_seq
    AS
    (
      SELECT 1 AS vSeq
      UNION ALL
      SELECT vSeq + 1
      FROM cte_seq
      WHERE vSeq < 200
    )
INSERT INTO #tmp_seq
SELECT * FROM cte_seq
OPTION (MAXRECURSION 200);

DECLARE @histogram_graph_xml XML
SET @histogram_graph_xml = NULL

;WITH source ([key], [val])
AS
(
  SELECT
    sh.range_high_key AS [key], CONVERT(BIGINT,sh.equal_rows) AS [val]
  FROM
    sys.stats AS s
  CROSS APPLY
    sys.dm_db_stats_histogram(s.object_id, s.stats_id) AS sh
  WHERE
    (name = @StatsName)
    AND (s.object_id = OBJECT_ID(@TableName))
),
      constants
AS
(
  SELECT
    @height AS height,
    '###' AS characters,
    ' ' AS separator
),
source_dimensions (kmin, kmax, vmin, vmax)
AS
(
  SELECT MIN([key]),
         MAX([key]),
         MIN([val]),
         MAX([val])
  FROM source,
       constants
),
actual_source (step, [key], [val])
AS
(
  SELECT TOP 200
         ROW_NUMBER() OVER (ORDER BY [key]),
         [key],
         [val]
  FROM source,
       constants
  ORDER BY [key]
),
actual_dimensions
AS
(
  SELECT MIN([key]) AS kmin,
         MAX([key]) AS kmax,
         MIN([val]) AS vmin,
         MAX([val]) AS vmax,
         COUNT(*) AS vcount
  FROM actual_source,
       constants
),
dims_and_consts
AS
(
  SELECT *,
         (bar_width - LEN(CONVERT(VARCHAR, kmin)) - LEN(CONVERT(VARCHAR, kmax))) AS x_label_pad
  FROM (SELECT *,
               (LEN(characters) + LEN(separator)) * vcount AS bar_width
        FROM actual_dimensions,
             constants) AS temp
)
,
cte_x (x)
AS
(
  SELECT value
  FROM dims_and_consts
  CROSS APPLY (SELECT vSeq FROM #tmp_seq WHERE vSeq <= vcount) AS t1(value)
),
cte_y (y)
AS
(
  SELECT value
  FROM dims_and_consts
  CROSS APPLY (SELECT vSeq FROM #tmp_seq WHERE vSeq <= height) AS t1(value)
),
cte_1
AS
(
  SELECT cte_y.y,
         RIGHT(REPLICATE(' ', CASE WHEN LEN(vmax) < 5 THEN 5 ELSE LEN(vmax)END)
               + CONVERT(VARCHAR, cte_y.y * (vmax) / (height)), CASE WHEN LEN(vmax) < 5 THEN 5 ELSE LEN(vmax)END)
         + ' | ' cBar1,
         CASE
           WHEN height * actual_source.[val] / (CASE WHEN vmax - vmin = 0 THEN 1 ELSE vmax - vmin END) >= cte_y.y THEN characters
           ELSE REPLICATE(' ', LEN(characters))
         END AS cBar2
  FROM cte_x
  LEFT JOIN actual_source
  ON actual_source.step = cte_x.x,
       cte_y,
       dims_and_consts
),
chart (rn, chart)
AS
(
  SELECT 9223372036854775807,
         REPLICATE('-', CASE WHEN LEN(vmax) < 5 THEN 5 ELSE LEN(vmax)END) + '-+-'
         + REPLICATE('-',
                     LEN((SELECT RIGHT('000' + CONVERT(VARCHAR, vSeq), 3) + ' '
                          FROM dims_and_consts
                          CROSS APPLY (SELECT vSeq FROM #tmp_seq WHERE vSeq <= vcount) AS t
                         FOR XML PATH(''))) + 1)
  FROM dims_and_consts
  UNION ALL
  SELECT a.y,
         cBar1 + CONVERT(VARCHAR(MAX), (SELECT ' ' + b.cBar2 FROM cte_1 b WHERE a.y = b.y FOR XML PATH(''), TYPE))
  FROM cte_1 a
  GROUP BY a.y,
           a.cBar1
  UNION ALL
  SELECT 0,
         REPLICATE('-', CASE WHEN LEN(vmax) < 5 THEN 5 ELSE LEN(vmax)END) + '-+-'
         + REPLICATE('-',
                     LEN((SELECT RIGHT('000' + CONVERT(VARCHAR, vSeq), 3) + ' '
                          FROM dims_and_consts
                          CROSS APPLY (SELECT vSeq FROM #tmp_seq WHERE vSeq <= vcount) AS t
                         FOR XML PATH(''))) + 1)
  FROM dims_and_consts
  UNION ALL
  SELECT -1,
         'Step     ' + SUBSTRING(t.col1, 1, LEN(t.col1)) AS t
  FROM (SELECT RIGHT('000' + CONVERT(VARCHAR, vSeq), 3) + ' '
                        FROM dims_and_consts
                        CROSS APPLY (SELECT vSeq FROM #tmp_seq WHERE vSeq <= vcount) AS t
                       FOR XML PATH('')) AS t(col1)
)
SELECT @histogram_graph_xml = (
SELECT chart AS c
FROM chart
ORDER BY rn DESC
FOR XML PATH(''))
OPTION (MAXRECURSION 200);

SELECT @histogram_graph_xml AS HistGraph

SELECT
  sh.*
FROM
  sys.stats AS s
CROSS APPLY
  sys.dm_db_stats_histogram(s.object_id, s.stats_id) AS sh
WHERE
  (name = @StatsName)
  AND (s.object_id = OBJECT_ID(@TableName))
GO
