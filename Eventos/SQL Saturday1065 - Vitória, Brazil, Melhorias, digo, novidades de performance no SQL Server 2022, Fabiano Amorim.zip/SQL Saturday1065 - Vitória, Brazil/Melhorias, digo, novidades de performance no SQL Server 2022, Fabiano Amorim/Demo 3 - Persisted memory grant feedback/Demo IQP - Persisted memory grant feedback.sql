/*
  IQP SQL Server 2022 - Persisted memory grant feedback
  Fabiano Amorim - amorim@pythian.com
*/
USE Northwind
GO

EXEC sys.sp_configure N'max server memory (MB)', N'10240' -- 10GB
GO
RECONFIGURE WITH OVERRIDE
GO


-- Disable QS
ALTER DATABASE Northwind SET QUERY_STORE CLEAR ALL
ALTER DATABASE Northwind SET QUERY_STORE = OFF
GO


-- Create 1 million rows test table
-- 3 secs to run
IF OBJECT_ID('ProductsMemoryGrantFeedback') IS NOT NULL
BEGIN
  DROP TABLE ProductsMemoryGrantFeedback
END
GO
SELECT TOP 1000000 
       ISNULL(ROW_NUMBER() OVER(ORDER BY (SELECT 1)),0) AS ProductID, 
       SubString(CONVERT(VarChar(250),NEWID()),1,8) AS ProductName, 
       CONVERT(VarChar(250), NEWID()) AS Col1
  INTO ProductsMemoryGrantFeedback
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
OPTION (MAXDOP 8)
GO
ALTER TABLE ProductsMemoryGrantFeedback ADD CONSTRAINT xpk_ProductsMemoryGrantFeedback PRIMARY KEY(ProductID)
GO
ALTER TABLE ProductsMemoryGrantFeedback ADD ColTest Char(1700) NULL
GO


-- Creating proc to test MemoryGrantFeedback
DROP PROC IF EXISTS st_MemoryGrantFeedback
GO
CREATE PROCEDURE st_MemoryGrantFeedback @ProductID_1 INT, @ProductID_2 INT
AS
BEGIN
  DECLARE @ProductID BIGINT, @ColTest CHAR(1700), 
          @Col1 VARCHAR(250), @ProductName VARCHAR(8)
  SELECT @ProductID = ProductID, 
         @ProductName = ProductName,
         @Col1 = Col1,
         @ColTest = ColTest
    FROM ProductsMemoryGrantFeedback
   WHERE ProductID BETWEEN @ProductID_1 AND @ProductID_2
   ORDER BY ColTest
  OPTION (MAXDOP 1)
END
GO

-- Compatibility level = 100 (SQL2008)
ALTER DATABASE Northwind SET COMPATIBILITY_LEVEL = 100
GO

ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE
GO
-- Spill to tempdb...
EXEC st_MemoryGrantFeedback @ProductID_1 = 1, @ProductID_2 = 5000;
GO
-- How bad is spill to tempdb?


-- Run on ostress (50 threads 50 iterations)
-- 10-20 seconds to run
-- Several spills and high tempdb usage
EXEC xp_cmdshell 'powershell ""C:\RMLUtils\ostress.exe" -E -Sdellfabiano\sql2022 -n50 -r50 -dNorthwind -q -Q""DECLARE @ProductID_2 INT = ABS(CONVERT(INT, CRYPT_GEN_RANDOM(4) % 10000)); EXEC st_MemoryGrantFeedback @ProductID_1 = 1, @ProductID_2 = @ProductID_2;"""'
-- Check tempdb writes on Resource Monitor

-- Try again with compatibility level = 160 (SQL2022)
-- QS disabled
ALTER DATABASE Northwind SET COMPATIBILITY_LEVEL = 160
ALTER DATABASE SCOPED CONFIGURATION SET ROW_MODE_MEMORY_GRANT_FEEDBACK = ON
ALTER DATABASE SCOPED CONFIGURATION SET BATCH_MODE_MEMORY_GRANT_FEEDBACK = ON
ALTER DATABASE Northwind SET QUERY_STORE CLEAR ALL
ALTER DATABASE Northwind SET QUERY_STORE = OFF
GO

-- Run on ostress (50 threads 50 iterations)
-- 4-6 seconds to run
EXEC xp_cmdshell 'powershell ""C:\RMLUtils\ostress.exe" -E -Sdellfabiano\sql2022 -n50 -r50 -dNorthwind -q -Q""DECLARE @ProductID_2 INT = ABS(CONVERT(INT, CRYPT_GEN_RANDOM(4) % 10000)); EXEC st_MemoryGrantFeedback @ProductID_1 = 1, @ProductID_2 = @ProductID_2;"""'
GO



-- Show problem with non-persisted feedback

-- Clear cache
DBCC FREEPROCCACHE(); WAITFOR DELAY '00:00:01';
GO
-- First execution will use tempdb
-- IsMemoryGrantFeedbackAdjusted="No: First Execution"
EXEC st_MemoryGrantFeedback @ProductID_1 = 1, @ProductID_2 = 10000;
GO
-- Second execution will adjust the memory and avoid the spill
-- IsMemoryGrantFeedbackAdjusted="Yes: Adjusting"
EXEC st_MemoryGrantFeedback @ProductID_1 = 1, @ProductID_2 = 10000;
GO

-- If you clear cache, the learning feedback is lost
DBCC FREEPROCCACHE(); WAITFOR DELAY '00:00:01';
GO
-- Back to spill
EXEC st_MemoryGrantFeedback @ProductID_1 = 1, @ProductID_2 = 10000;
GO


-- Enable QS to get persisted memory grant feedback
ALTER DATABASE Northwind SET QUERY_STORE 
(OPERATION_MODE = READ_WRITE, DATA_FLUSH_INTERVAL_SECONDS = 60, INTERVAL_LENGTH_MINUTES = 1, QUERY_CAPTURE_MODE = ALL)
ALTER DATABASE Northwind SET QUERY_STORE CLEAR ALL
GO
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE
GO

-- Clear cache
DBCC FREEPROCCACHE(); WAITFOR DELAY '00:00:01';
GO
-- First execution will use tempdb
-- IsMemoryGrantFeedbackAdjusted="No: First Execution"
EXEC st_MemoryGrantFeedback @ProductID_1 = 1, @ProductID_2 = 10000;
GO
-- Second execution will adjust the memory and avoid the spill
-- IsMemoryGrantFeedbackAdjusted="Yes: Adjusting"
EXEC st_MemoryGrantFeedback @ProductID_1 = 1, @ProductID_2 = 10000;
GO

-- What now?
DBCC FREEPROCCACHE(); WAITFOR DELAY '00:00:01';
GO
-- All good, no spill as the feedback info is persisted on QS
EXEC st_MemoryGrantFeedback @ProductID_1 = 1, @ProductID_2 = 10000;
GO


-- Query persisted feedback
SELECT qpf.feature_desc, 
       qpf.feedback_data, 
       qpf.state_desc, 
       qt.query_sql_text,
        (qrs.last_query_max_used_memory * 8192)/1024/1024 as last_query_memory_mb
FROM sys.query_store_plan_feedback qpf
JOIN sys.query_store_plan qp
ON qpf.plan_id = qp.plan_id
JOIN sys.query_store_query qq
ON qp.query_id = qq.query_id
JOIN sys.query_store_query_text qt
ON qq.query_text_id = qt.query_text_id
JOIN sys.query_store_runtime_stats qrs
ON qp.plan_id = qrs.plan_id
AND qt.query_sql_text NOT LIKE '%sys.%';
GO


-- I would like to see an option to have 
-- better exposure/manage to dynamic 
-- additional memory grant requests


-- Creating a table
IF OBJECT_ID('SortTable') IS NOT NULL
		DROP TABLE SortTable
GO
SELECT TOP 200000
			    IDENTITY(INT, 1,1) AS OrderID,
			    ABS(CHECKSUM(NEWID()) / 10000000) AS CustomerID,
			    CONVERT(DATETIME, GETDATE() - (CHECKSUM(NEWID()) / 1000000)) AS OrderDate,
			    ISNULL(ABS(CONVERT(NUMERIC(18,2), (CHECKSUM(NEWID()) / 1000000.5))),0) AS Value,
			    CONVERT(CHAR(500), NEWID()) AS ColChar
		INTO SortTable
		FROM sysobjects A
	CROSS JOIN sysobjects B CROSS JOIN sysobjects C CROSS JOIN sysobjects D
GO
CREATE CLUSTERED INDEX ix1 ON SortTable (OrderID)
GO

-- Clear and disable QS
ALTER DATABASE Northwind SET COMPATIBILITY_LEVEL = 160
ALTER DATABASE SCOPED CONFIGURATION SET ROW_MODE_MEMORY_GRANT_FEEDBACK = ON
ALTER DATABASE SCOPED CONFIGURATION SET BATCH_MODE_MEMORY_GRANT_FEEDBACK = ON
ALTER DATABASE Northwind SET QUERY_STORE CLEAR ALL
ALTER DATABASE Northwind SET QUERY_STORE = OFF
GO

-- This will spill to tempdb
DECLARE @v1 Char(500), @v2 INT
SELECT @v1 = ColChar, @v2 = OrderID
		FROM SortTable
	ORDER BY ColChar
OPTION  (MAXDOP 1, RECOMPILE)
GO

DROP INDEX IF EXISTS ixColChar ON SortTable
GO
-- This will call additional_memory_grant 
-- and avoid spill
CREATE INDEX ixColChar ON SortTable(ColChar)
WITH(MAXDOP = 1, ONLINE=ON)
GO
DROP INDEX IF EXISTS ixColChar ON SortTable
GO

-- Sort running on batch mode also does the additional
-- mem request
DECLARE @v1 CHAR(500), @v2 INT, @i INT = 0
SELECT @v1 = ColChar, @v2 = OrderID
		FROM SortTable
 WHERE OrderID >= @i
	ORDER BY ColChar
OPTION  (MAXDOP 1, USE HINT ('OVERRIDE_BATCH_MODE_HEURISTICS'))
GO

-- If OVERRIDE_BATCH_MODE_HEURISTICS doesn't make operatores to run
-- in batch, the old and nice workaround may do...
DROP INDEX IF EXISTS ix2 ON SortTable
GO
CREATE NONCLUSTERED COLUMNSTORE INDEX ix2 ON SortTable(OrderID, ColChar)
WHERE OrderID = -1
GO

DECLARE @v1 CHAR(500), @v2 INT, @i INT = 0
SELECT @v1 = ColChar, @v2 = OrderID
		FROM SortTable
 WHERE OrderID >= @i
	ORDER BY ColChar
OPTION  (MAXDOP 1)
GO