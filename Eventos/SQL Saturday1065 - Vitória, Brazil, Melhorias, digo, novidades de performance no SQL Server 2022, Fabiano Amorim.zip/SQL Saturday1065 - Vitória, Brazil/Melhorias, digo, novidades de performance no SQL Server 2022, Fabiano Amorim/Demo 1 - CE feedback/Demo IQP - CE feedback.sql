/*
  IQP SQL Server 2022 - CE feedback
  Fabiano Amorim - amorim@pythian.com
*/

USE Northwind
GO
-- Demo 1

-- 8 seconds to run
IF OBJECT_ID('CustomersBig') IS NOT NULL
  DROP TABLE CustomersBig
GO
SELECT TOP 2000000
       ISNULL(ROW_NUMBER() OVER(ORDER BY (SELECT 1)),0) AS CustomerID, 
       SUBSTRING(CONVERT(VARCHAR(250),NEWID()),1,8) AS ContactName, 
       CONVERT(VARCHAR(250), NEWID()) AS Col1
  INTO CustomersBig
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
OPTION (MAXDOP 8)
GO
ALTER TABLE CustomersBig ADD CONSTRAINT xpk_CustomersBig PRIMARY KEY(CustomerID)
GO
IF OBJECT_ID('InactiveIDs') IS NOT NULL
  DROP TABLE InactiveIDs
GO
SELECT TOP 10000000 
       ISNULL((1500000) + ROW_NUMBER() OVER(ORDER BY (SELECT 1)),0) AS InactiveID
  INTO InactiveIDs
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
OPTION (MAXDOP 8)
GO
ALTER TABLE InactiveIDs ADD CONSTRAINT xpk_InactiveIDs PRIMARY KEY(InactiveID)
GO
-- Compatibility level = 160 (SQL2022)
ALTER DATABASE Northwind SET COMPATIBILITY_LEVEL = 160
GO
-- Enable and clean QS
ALTER DATABASE Northwind SET QUERY_STORE (OPERATION_MODE = READ_WRITE, DATA_FLUSH_INTERVAL_SECONDS = 60, INTERVAL_LENGTH_MINUTES = 1, QUERY_CAPTURE_MODE = ALL)
ALTER DATABASE Northwind SET QUERY_STORE CLEAR ALL
GO
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE 
GO

-- Creating proc to test
-- List one inactive customer
DROP PROC IF EXISTS st_CE_Feedback_RowGoal
GO
CREATE PROCEDURE st_CE_Feedback_RowGoal
AS
BEGIN
  SELECT TOP 1 *
    FROM CustomersBig
   WHERE EXISTS(SELECT 1 
                  FROM InactiveIDs  
                 WHERE InactiveIDs.InactiveID = CustomersBig.CustomerID)
END
GO

-- Test sp
-- Enable actual plan...
SET STATISTICS IO, TIME ON
EXEC st_CE_Feedback_RowGoal
SET STATISTICS IO, TIME OFF
GO
/*
Table 'InactiveIDs'. Scan count 1, logical reads 4593762
Table 'CustomersBig'. Scan count 1, logical reads 12541
SQL Server Execution Times:
  CPU time = 1937 ms,  elapsed time = 1981 ms.
*/

-- 31 seconds to run
EXEC st_CE_Feedback_RowGoal
GO 14 
/* run for another 14 times, to get total of 15 executions
   15 is the internal threshold to enable CE feedback */



-- Start the CE_Feeback xEvent and watch live data
-- Run query one more time
EXEC st_CE_Feedback_RowGoal
GO


-- New entry on query_store_plan_feedback with a PENDING_VALIDATION
SELECT qpf.feature_desc, qpf.feedback_data, qpf.state_desc, 
       OBJECT_NAME(qq.object_id, DB_ID('Northwind')) AS obj_name,
       qt.query_sql_text
FROM sys.query_store_plan_feedback qpf
JOIN sys.query_store_plan qp
ON qpf.plan_id = qp.plan_id
JOIN sys.query_store_query qq
ON qp.query_id = qq.query_id
JOIN sys.query_store_query_text qt
ON qq.query_text_id = qt.query_text_id
WHERE qt.query_sql_text LIKE '%InactiveIDs%'
AND qt.query_sql_text NOT LIKE '%sys.%';
GO
-- Query exec stats
SELECT OBJECT_NAME(qq.object_id, DB_ID('Northwind')) AS obj_name,
       qt.query_sql_text, 
       SUM(qrs.count_executions) AS count_executions,
       AVG(qrs.avg_cpu_time) / 1000 AS avg_cpu_time_ms,
       MIN(qrs.min_cpu_time) / 1000 AS min_cpu_time_ms,
       MAX(qrs.max_cpu_time) / 1000 AS max_cpu_time_ms
FROM sys.query_store_plan qp
JOIN sys.query_store_query qq
ON qp.query_id = qq.query_id
JOIN sys.query_store_query_text qt
ON qq.query_text_id = qt.query_text_id
JOIN sys.query_store_runtime_stats qrs
ON qp.plan_id = qrs.plan_id
WHERE qt.query_sql_text LIKE '%InactiveIDs%'
AND qt.query_sql_text NOT LIKE '%sys.%'
GROUP BY OBJECT_NAME(qq.object_id, DB_ID('Northwind')),
         qt.query_sql_text
GO

-- Run query one more time
-- Notice the actual plan changed 
-- from a loop to a merge join
SET STATISTICS TIME, IO ON
EXEC st_CE_Feedback_RowGoal
SET STATISTICS TIME, IO OFF
GO
/*
Table 'InactiveIDs'. Scan count 1, logical reads 5
Table 'CustomersBig'. Scan count 1, logical reads 12539
SQL Server Execution Times:
  CPU time = 172 ms,  elapsed time = 195 ms.
*/

-- New entry on query_store_plan_feedback with a VERIFICATION_PASSED
SELECT qpf.feature_desc, qpf.feedback_data, qpf.state_desc, 
       OBJECT_NAME(qq.object_id, DB_ID('Northwind')) AS obj_name,
       qt.query_sql_text
FROM sys.query_store_plan_feedback qpf
JOIN sys.query_store_plan qp
ON qpf.plan_id = qp.plan_id
JOIN sys.query_store_query qq
ON qp.query_id = qq.query_id
JOIN sys.query_store_query_text qt
ON qq.query_text_id = qt.query_text_id
WHERE qt.query_sql_text LIKE '%InactiveIDs%'
AND qt.query_sql_text NOT LIKE '%sys.%';
GO
-- Query exec stats
SELECT OBJECT_NAME(qq.object_id, DB_ID('Northwind')) AS obj_name,
       qt.query_sql_text, 
       SUM(qrs.count_executions) AS count_executions,
       AVG(qrs.avg_cpu_time) / 1000 AS avg_cpu_time_ms,
       MIN(qrs.min_cpu_time) / 1000 AS min_cpu_time_ms,
       MAX(qrs.max_cpu_time) / 1000 AS max_cpu_time_ms
FROM sys.query_store_plan qp
JOIN sys.query_store_query qq
ON qp.query_id = qq.query_id
JOIN sys.query_store_query_text qt
ON qq.query_text_id = qt.query_text_id
JOIN sys.query_store_runtime_stats qrs
ON qp.plan_id = qrs.plan_id
WHERE qt.query_sql_text LIKE '%InactiveIDs%'
AND qt.query_sql_text NOT LIKE '%sys.%'
GROUP BY OBJECT_NAME(qq.object_id, DB_ID('Northwind')),
         qt.query_sql_text
GO

-- Run query one more time
-- Optimized plan with the forced hint
-- Check actual query plan properties 
-- to more details
EXEC st_CE_Feedback_RowGoal
GO



-- Demo 2

USE Northwind
GO
-- Create 2mi test table
-- Takes avg of 12 seconds to run on my laptop
IF OBJECT_ID('OrdersBigHistory') IS NOT NULL
  DROP TABLE OrdersBigHistory
GO
SELECT TOP 2000000
       ISNULL(ROW_NUMBER() OVER(ORDER BY (SELECT 1)),0) AS OrderID,
       ABS(CheckSUM(NEWID()) / 10000000) AS CustomerID,
       ABS(CheckSUM(NEWID()) / 10000000) AS EmployeeID,
       CONVERT(DateTime, GETDATE() - (CheckSUM(NEWID()) / 1000000)) AS OrderDate,
       ISNULL(ABS(CONVERT(Numeric(18,2), (CheckSUM(NEWID()) / 1000000.5))),0) AS Value,
       CONVERT(CHAR(1000), SUBSTRING(CONVERT(VarChar(250),NEWID()),1,20)) AS OrderNotes
  INTO OrdersBigHistory
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
OPTION (MAXDOP 4)
GO
ALTER TABLE OrdersBigHistory ADD CONSTRAINT xpk_OrdersBigHistory PRIMARY KEY(OrderID)
GO
;WITH CTE
AS
(
  SELECT CONVERT(DATETIME, DATEADD(HOUR, OrderID, CONVERT(DATETIME, '19000101'))) AS Col1, OrderDate, OrderID
    FROM OrdersBigHistory
)
UPDATE CTE SET OrderDate = Col1
GO
CREATE INDEX ixOrderDate ON OrdersBigHistory(OrderDate)
GO

-- Adjusting QS and DOP_FEEDBACK settings
ALTER DATABASE Northwind SET QUERY_STORE = ON
ALTER DATABASE Northwind SET QUERY_STORE (OPERATION_MODE = READ_WRITE, DATA_FLUSH_INTERVAL_SECONDS = 60, INTERVAL_LENGTH_MINUTES = 1, QUERY_CAPTURE_MODE = ALL)
ALTER DATABASE Northwind SET QUERY_STORE CLEAR ALL
ALTER DATABASE SCOPED CONFIGURATION SET CE_FEEDBACK = ON
GO

-- Creating proc to run tests
DROP PROC IF EXISTS st_1
GO
CREATE PROC st_1 @dt DATETIME
AS
SELECT TOP 10 OrderID
  FROM OrdersBigHistory
 WHERE OrderDate >= @dt
ORDER BY OrderID ASC
GO

-- Clear QS and plan cache
ALTER DATABASE Northwind SET QUERY_STORE CLEAR ALL
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE
GO
-- Calling proc for 15 times to reach internal threshold to be considered by CE feedback
EXEC st_1 @dt = '2126-12-31 23:59:59.997'
GO 15

-- Query is not considered for feedback as the estimated vs actual cardinality looks goood
-- Even though it is not true as it was estimating to read 10 rows but had to read almost 2mi rows
EXEC st_1 @dt = '2028-01-01 00:00:00.000'
GO

-- New entry on query_store_plan_feedback with a NO_RECOMMENDATION
SELECT qpf.feature_desc, qpf.feedback_data, qpf.state_desc, 
       OBJECT_NAME(qq.object_id, DB_ID('Northwind')) AS obj_name,
       qt.query_sql_text
FROM sys.query_store_plan_feedback qpf
JOIN sys.query_store_plan qp
ON qpf.plan_id = qp.plan_id
JOIN sys.query_store_query qq
ON qp.query_id = qq.query_id
JOIN sys.query_store_query_text qt
ON qq.query_text_id = qt.query_text_id
WHERE qt.query_sql_text LIKE '%OrdersBigHistory%'
AND qt.query_sql_text NOT LIKE '%sys.%';
GO
-- Query exec stats
SELECT OBJECT_NAME(qq.object_id, DB_ID('Northwind')) AS obj_name,
       qt.query_sql_text, 
       SUM(qrs.count_executions) AS count_executions,
       AVG(qrs.avg_cpu_time) / 1000 AS avg_cpu_time_ms,
       MIN(qrs.min_cpu_time) / 1000 AS min_cpu_time_ms,
       MAX(qrs.max_cpu_time) / 1000 AS max_cpu_time_ms
FROM sys.query_store_plan qp
JOIN sys.query_store_query qq
ON qp.query_id = qq.query_id
JOIN sys.query_store_query_text qt
ON qq.query_text_id = qt.query_text_id
JOIN sys.query_store_runtime_stats qrs
ON qp.plan_id = qrs.plan_id
WHERE qt.query_sql_text LIKE '%OrdersBigHistory%'
AND qt.query_sql_text NOT LIKE '%sys.%'
GROUP BY OBJECT_NAME(qq.object_id, DB_ID('Northwind')),
         qt.query_sql_text
GO

-- Running using TF9130 to show predicate as a filter
SELECT TOP 10 OrderID
  FROM OrdersBigHistory
 WHERE OrderDate >= '2126-12-31 23:59:59.997'
ORDER BY OrderID ASC
OPTION(QUERYTRACEON 9130)
GO

-- Run the query without row goal is definitely the best option
SELECT TOP 10 OrderID
  FROM OrdersBigHistory
 WHERE OrderDate >= '2126-12-31 23:59:59.997'
ORDER BY OrderID ASC
OPTION(USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
GO

-- Try again with an ugly "workaround" to avoid the predicate pushdown to the read operator
-- Recreating proc to run tests
DROP PROC IF EXISTS st_1
GO
CREATE PROC st_1 @dt DATETIME
AS
SELECT TOP 10 OrderID
  FROM OrdersBigHistory
 WHERE OrderDate >= (SELECT MIN(t.dt) FROM (VALUES(@dt)) AS t(dt))
ORDER BY OrderID ASC
GO

-- Clear QS and plan cache
ALTER DATABASE Northwind SET QUERY_STORE CLEAR ALL
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE
GO

-- 15 seconds to run
EXEC st_1 @dt = '2126-12-31 23:59:59.997'
GO 15

-- Next call should check for feedback
-- Now feedback is considered and validation is pending (should be validated on next exec)
EXEC st_1 @dt = '2126-12-31 23:59:59.997'
GO

-- New entry on query_store_plan_feedback with a PENDING_VALIDATION
SELECT qpf.feature_desc, qpf.feedback_data, qpf.state_desc, 
       OBJECT_NAME(qq.object_id, DB_ID('Northwind')) AS obj_name,
       qt.query_sql_text
FROM sys.query_store_plan_feedback qpf
JOIN sys.query_store_plan qp
ON qpf.plan_id = qp.plan_id
JOIN sys.query_store_query qq
ON qp.query_id = qq.query_id
JOIN sys.query_store_query_text qt
ON qq.query_text_id = qt.query_text_id
WHERE qt.query_sql_text LIKE '%OrdersBigHistory%'
AND qt.query_sql_text NOT LIKE '%sys.%';
GO
-- Query exec stats
SELECT OBJECT_NAME(qq.object_id, DB_ID('Northwind')) AS obj_name,
       qt.query_sql_text, 
       SUM(qrs.count_executions) AS count_executions,
       AVG(qrs.avg_cpu_time) / 1000 AS avg_cpu_time_ms,
       MIN(qrs.min_cpu_time) / 1000 AS min_cpu_time_ms,
       MAX(qrs.max_cpu_time) / 1000 AS max_cpu_time_ms
FROM sys.query_store_plan qp
JOIN sys.query_store_query qq
ON qp.query_id = qq.query_id
JOIN sys.query_store_query_text qt
ON qq.query_text_id = qt.query_text_id
JOIN sys.query_store_runtime_stats qrs
ON qp.plan_id = qrs.plan_id
WHERE qt.query_sql_text LIKE '%OrdersBigHistory%'
AND qt.query_sql_text NOT LIKE '%sys.%'
GROUP BY OBJECT_NAME(qq.object_id, DB_ID('Northwind')),
         qt.query_sql_text
GO

-- Next call will validate the feedback and add OPTION(USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
-- Notice the plan is already diff, now it is doing the seek on ixOrderDate
-- This should take 36ms to run.
EXEC st_1 @dt = '2126-12-31 23:59:59.997'
GO

-- All good... plan now is forced via QS query hint
EXEC st_1 @dt = '2126-12-31 23:59:59.997'
GO
/*
QueryStoreStatementHintId="1" 
QueryStoreStatementHintText="OPTION(USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))" 
QueryStoreStatementHintSource="CE feedback"
*/


-- What if the scenario changes?
-- For this value, the other plan is better
-- but, you'll be stuck with forced hint until you 
-- remove/disable it from QS
EXEC st_1 @dt = '1900-01-01 00:00:00.000' WITH RECOMPILE
GO


/*
Note: 
The plan stored on QS looks "incorrect"... it is storing the "old" plan, the one without the hint, 
in this case, the one doing the scan.
Also, the query_plan_hash stored on QS looks correct, but the hash on XML plan, is the one
on "old" plan. So, a bit weird to see a different query plan hash, plan id but same plan.
Looks even weird if analyzed via QS graphs as it would show 2 diff plans but with same shape/xml.
*/
SELECT * FROM Northwind.sys.query_store_plan_feedback
GO
SELECT * FROM Northwind.sys.query_store_query_hints
GO
;WITH XMLNAMESPACES('http://schemas.microsoft.com/sqlserver/2004/07/showplan' AS p)
SELECT 
query_store_plan.plan_id,
query_store_plan.query_id,
query_store_plan.last_execution_time,
query_store_plan.query_plan_hash AS qs_query_plan_hash,
t_batch.batch_plan.value('(//p:StmtSimple/@QueryPlanHash)[1]', 'VARCHAR(500)') AS xml_query_plan_hash,
query_store_query.context_settings_id,
qs.count_executions,
qs.avg_duration_sec,
qs.avg_cpu_time_sec,
query_store_query_text.query_sql_text,
t.xml_plan
FROM Northwind.sys.query_store_plan
CROSS APPLY (SELECT CONVERT(XML, query_store_plan.query_plan) AS xml_plan) AS t
INNER JOIN Northwind.sys.query_store_query
ON query_store_plan.query_id = query_store_query.query_id
INNER JOIN Northwind.sys.query_store_query_text
ON query_store_query.query_text_id = query_store_query_text.query_text_id
CROSS APPLY (SELECT SUM(count_executions) AS count_executions, 
                    CONVERT(NUMERIC(18, 4), AVG(query_store_runtime_stats.avg_duration) /1000. /1000.) AS avg_duration_sec,
                    CONVERT(NUMERIC(18, 4), AVG(query_store_runtime_stats.avg_cpu_time) /1000. /1000.) AS avg_cpu_time_sec
             FROM Northwind.sys.query_store_runtime_stats
             WHERE query_store_runtime_stats.plan_id = query_store_plan.plan_id) AS qs
OUTER APPLY t.xml_plan.nodes('//p:Batch') AS t_batch(batch_plan)
WHERE query_store_plan.query_plan LIKE '%OrdersBigHistory%'
AND query_store_plan.query_plan NOT LIKE '%sys.%'
ORDER BY query_store_plan.last_execution_time DESC
GO
-- Check the query plan hash...
-- This is the seek.. the plan with the query hint
SELECT a.usecounts,
       a.cacheobjtype,
       a.objtype,
       b.text,
       c.query_plan,
       d.query_hash,
       d.query_plan_hash
  FROM sys.dm_exec_cached_plans a
 CROSS APPLY sys.dm_exec_sql_text (a.plan_handle) b
 CROSS APPLY sys.dm_exec_query_plan (a.plan_handle) c
 INNER JOIN sys.dm_exec_query_stats d
    ON a.plan_handle = d.plan_handle
 WHERE "text" NOT LIKE '%sys.%'
   AND d.query_plan_hash = 0xABB72A6A6262271F
 ORDER BY creation_time ASC
GO



/*
In first CTP releases, I was able to use TF9130 as an workaround for this, but
for now, it is just not working as even after the new plan is evaluated, CE feedback 
never get changed from pending to verification passed or failed...
*/
-- Re-creating proc to run tests
DROP PROC IF EXISTS st_1
GO
CREATE PROC st_1 @dt DATETIME
AS
SELECT TOP 10 OrderID
  FROM OrdersBigHistory
 WHERE OrderDate >= @dt
ORDER BY OrderID ASC
GO
-- Clear QS and plan cache
ALTER DATABASE Northwind SET QUERY_STORE CLEAR ALL
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE
GO

-- Try again with 9130 enabled
DBCC TRACEON(9130)
GO
-- 16 seconds to run
EXEC st_1 @dt = '2126-12-31 23:59:59.997'
GO 15

-- Next call should check for feedback
-- Now feedback is considered and validation is pending (should be validated on next exec)
EXEC st_1 @dt = '2126-12-31 23:59:59.997'
GO

-- Next call will validate the feedback and add OPTION(USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
-- Notice the plan is already diff, now it is doing the seek on ixOrderDate
-- This should take 9ms to run.
EXEC st_1 @dt = '2126-12-31 23:59:59.997'
GO

-- This is back to 9 seconds and the scan :-( ... 
-- Validation should pass and plan to be forced
-- You can re-execute this for how many times you want, but feedback will still be pending validation...
EXEC st_1 @dt = '2126-12-31 23:59:59.997'
GO

-- New entry on query_store_plan_feedback with a PENDING_VALIDATION
SELECT qpf.feature_desc, qpf.feedback_data, qpf.state_desc, 
       OBJECT_NAME(qq.object_id, DB_ID('Northwind')) AS obj_name,
       qt.query_sql_text
FROM sys.query_store_plan_feedback qpf
JOIN sys.query_store_plan qp
ON qpf.plan_id = qp.plan_id
JOIN sys.query_store_query qq
ON qp.query_id = qq.query_id
JOIN sys.query_store_query_text qt
ON qq.query_text_id = qt.query_text_id
WHERE 1=1
AND qt.query_sql_text NOT LIKE '%sys.%';
GO
-- Query exec stats
SELECT OBJECT_NAME(qq.object_id, DB_ID('Northwind')) AS obj_name,
       qt.query_sql_text, 
       SUM(qrs.count_executions) AS count_executions,
       AVG(qrs.avg_cpu_time) / 1000 AS avg_cpu_time_ms,
       MIN(qrs.min_cpu_time) / 1000 AS min_cpu_time_ms,
       MAX(qrs.max_cpu_time) / 1000 AS max_cpu_time_ms
FROM sys.query_store_plan qp
JOIN sys.query_store_query qq
ON qp.query_id = qq.query_id
JOIN sys.query_store_query_text qt
ON qq.query_text_id = qt.query_text_id
JOIN sys.query_store_runtime_stats qrs
ON qp.plan_id = qrs.plan_id
WHERE 1=1
AND qt.query_sql_text NOT LIKE '%sys.%'
GROUP BY OBJECT_NAME(qq.object_id, DB_ID('Northwind')),
         qt.query_sql_text
GO


DBCC TRACEOFF(9130)
GO


-- If you add some complexity it won't 
-- trigger the feedback

-- Re-creating proc to run tests
-- Using make_parallel to increase query cost and 
-- "force" parallelism
DROP PROC IF EXISTS st_1
GO
CREATE PROC st_1 @dt DATETIME
AS
SELECT TOP 1 OrderID
  FROM OrdersBigHistory
  CROSS APPLY dbo.make_parallel() AS m
 WHERE OrderDate >= (SELECT MIN(t.dt) FROM (VALUES(@dt)) AS t(dt))
ORDER BY OrderID ASC
GO

-- Clear QS and plan cache
ALTER DATABASE Northwind SET QUERY_STORE CLEAR ALL
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE
GO

-- 22 seconds to run
EXEC st_1 @dt = '2126-12-31 23:59:59.997'
GO 15

-- This should get a feedback
EXEC st_1 @dt = '2126-12-31 23:59:59.997'
GO

-- New entry on query_store_plan_feedback with a NO_RECOMMENDATION
SELECT qpf.feature_desc, qpf.feedback_data, qpf.state_desc, 
       OBJECT_NAME(qq.object_id, DB_ID('Northwind')) AS obj_name,
       qt.query_sql_text
FROM sys.query_store_plan_feedback qpf
JOIN sys.query_store_plan qp
ON qpf.plan_id = qp.plan_id
JOIN sys.query_store_query qq
ON qp.query_id = qq.query_id
JOIN sys.query_store_query_text qt
ON qq.query_text_id = qt.query_text_id
WHERE qt.query_sql_text LIKE '%OrdersBigHistory%'
AND qt.query_sql_text NOT LIKE '%sys.%';
GO

