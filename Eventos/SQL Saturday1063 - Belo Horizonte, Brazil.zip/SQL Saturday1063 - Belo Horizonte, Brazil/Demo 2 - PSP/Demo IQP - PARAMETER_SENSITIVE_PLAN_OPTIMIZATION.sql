/*
  IQP SQL Server 2022 - Parameter sensitive plan optimization
  Fabiano Amorim - amorim@pythian.com
*/

/*
---------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------
Overview of query otimizer and parameter sniffing problem
You say what you want and QO creates a code/plan to do it.
Google maps analogy
Parallel plan analogy - Split work by multiple threads... Count number of people in a room
---------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------
*/

USE Northwind
GO
EXECUTE sp_configure 'show advanced options', 1;  
GO  
RECONFIGURE;  
GO 
EXEC sys.sp_configure N'max degree of parallelism', N'4'
GO
RECONFIGURE WITH OVERRIDE
GO
-- 5 secs to run
IF OBJECT_ID('OrdersBig') IS NOT NULL
  DROP TABLE OrdersBig
GO
SELECT TOP 5000000
       ISNULL(ROW_NUMBER() OVER(ORDER BY (SELECT 1)),0) AS OrderID,
       ABS(CheckSUM(NEWID()) / 10000000) AS CustomerID,
       ABS(CONVERT(INT, CRYPT_GEN_RANDOM(4) % 5)) AS EmployeeID,
       CONVERT(DATE, GETDATE() - (CHECKSUM(NEWID()) / 1000000)) AS OrderDate,
       ISNULL(ABS(CONVERT(NUMERIC(18,2), (CHECKSUM(NEWID()) / 1000000.5))),0) AS Value
  INTO OrdersBig
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
OPTION (MAXDOP 8)
GO
INSERT INTO OrdersBig WITH(TABLOCK)
SELECT TOP 2000000
       ISNULL(5000000 + ROW_NUMBER() OVER(ORDER BY (SELECT 1)),0) AS OrderID,
       ABS(CheckSUM(NEWID()) / 10000000) AS CustomerID,
       ABS(CheckSUM(NEWID()) / 1000) AS EmployeeID,
       CONVERT(Date, GETDATE() - (CheckSUM(NEWID()) / 1000000)) AS OrderDate,
       ISNULL(ABS(CONVERT(Numeric(18,2), (CheckSUM(NEWID()) / 1000000.5))),0) AS Value
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
OPTION (MAXDOP 8)
GO
ALTER TABLE OrdersBig ADD CONSTRAINT xpk_OrdersBig PRIMARY KEY(OrderID) WITH(MAXDOP = 8)
GO
CREATE INDEX ixEmployeeID ON OrdersBig (EmployeeID) WITH(MAXDOP = 8)
GO


-- Compatibility level = 100 (SQL2008)
ALTER DATABASE Northwind SET COMPATIBILITY_LEVEL = 100
GO
-- Enable and clean QS
ALTER DATABASE Northwind SET QUERY_STORE 
(OPERATION_MODE = READ_WRITE, DATA_FLUSH_INTERVAL_SECONDS = 60, INTERVAL_LENGTH_MINUTES = 1, QUERY_CAPTURE_MODE = ALL)
ALTER DATABASE Northwind SET QUERY_STORE CLEAR ALL
GO

-- Creating proc to test PSP
DROP PROC IF EXISTS st_Psp
GO
CREATE PROCEDURE st_Psp @EmployeeID INT
AS
BEGIN
   SELECT CustomerID, COUNT(*) AS Cnt, MAX(OrderDate) AS MaxOrderDate
     FROM OrdersBig
    WHERE EmployeeID = @EmployeeID
    GROUP BY CustomerID
    ORDER BY MaxOrderDate
END
GO


-- Run proc and save some results in a table
-- On first execution run with a param from 0 to 5...
-- This will process a lot of rows
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE
GO
EXEC st_Psp 1;
EXEC st_Psp 43929;

-- Run on ostress
-- One initial call to create bad plan
EXEC xp_cmdshell 'powershell ""C:\RMLUtils\ostress.exe" -E -Sdellfabiano\sql2022 -n1 -r1 -dNorthwind -q -Q""DBCC FREEPROCCACHE(); EXEC st_Psp 1"""'

-- Call sp with EmployeeID 43929
EXEC xp_cmdshell 'powershell ""C:\RMLUtils\ostress.exe" -E -Sdellfabiano\sql2022 -n5 -r10000 -dNorthwind -q -Q""EXEC st_Psp 43929"""'


-- While is running... check whoisactive
-- See plan and parameter compiled value
sp_WhoIsActive @get_plans = 1
GO
-- Open PerfmonPSP.msc and check CPU and batch requests/sec

-- Bad plan being reused...
SELECT a.usecounts,
       a.cacheobjtype,
       a.objtype,
       b.text AS query,
       c.query_plan
  FROM sys.dm_exec_cached_plans a
 CROSS APPLY sys.dm_exec_sql_text (a.plan_handle) b
 CROSS APPLY sys.dm_exec_query_plan (a.plan_handle) c
 WHERE "text" NOT LIKE '%sys.%'
ORDER BY a.usecounts DESC
GO

-- How to fix it? 
DBCC FREEPROCCACHE()
GO
/*
  Or: 
  OPTION (RECOMPILE)
  OPTIMIZE FOR... and etc
*/

-- Query Store will show 2 plans... 1 optimized for a few rows and 
-- another one optimized for many rows

-- Try again with compatibility level = 160 (SQL2022)
ALTER DATABASE Northwind SET COMPATIBILITY_LEVEL = 160
ALTER DATABASE SCOPED CONFIGURATION SET PARAMETER_SENSITIVE_PLAN_OPTIMIZATION = ON
GO
ALTER DATABASE Northwind SET QUERY_STORE CLEAR ALL
DBCC FREEPROCCACHE()
GO

-- Run on ostress
-- One initial call to create bad plan
EXEC xp_cmdshell 'powershell ""C:\RMLUtils\ostress.exe" -E -Sdellfabiano\sql2022 -n1 -r1 -dNorthwind -q -Q""DBCC FREEPROCCACHE(); EXEC st_Psp 1"""'

-- Call sp with EmployeeID 43929
EXEC xp_cmdshell 'powershell ""C:\RMLUtils\ostress.exe" -E -Sdellfabiano\sql2022 -n5 -r10000 -dNorthwind -q -Q""EXEC st_Psp 43929"""'


-- While is running... check whoisactive
-- See plan and parameter compiled value
sp_WhoIsActive @get_plans = 1
GO
-- Open PerfmonPSP.msc and check CPU and batch requests/sec

/*
  Some notes:

  - Some limitations on V1...
  ---- Requires a high order of magnitude of possible difference to be enabled
  ---- Only works for pure SELECT statements
  ---- Only works for equality filters
  ---- For all 40 skip reasons: SELECT map_value FROM sys.dm_xe_map_values WHERE name = 'psp_skipped_reason_enum'
  - Using column statistics to identify the skewness
  - On by default, use "ALTER DATABASE SCOPED CONFIGURATION SET PARAMETER_SENSITIVE_PLAN_OPTIMIZATION = OFF" to disable it
  - Use OPTION (USE HINT('DISABLE_PARAMETER_SENSITIVE_PLAN_OPTIMIZATION')
  - xEvents available to track usage
  ---- parameter_sensitive_plan_optimization_skipped_reason, parameter_sensitive_plan_optimization and parameter_sensitive_plan_testing
  - Object_ID on cached plan is not available
*/



DBCC FREEPROCCACHE()
GO

-- This is not elegible for PSP optimization
-- parameter_sensitive_plan_optimization_skipped_reason = AutoParameterized
SELECT *
FROM OrdersBig
WHERE EmployeeID = 43929
GO
-- This is not elegible for PSP optimization
-- parameter_sensitive_plan_optimization_skipped_reason = HasLocalVar
DECLARE @EmployeeID INT = 43929
SELECT *
FROM OrdersBig
WHERE EmployeeID = @EmployeeID
GO
-- This is not elegible for PSP optimization
-- parameter_sensitive_plan_optimization_skipped_reason = OutputOrModifiedParam
EXEC sp_executesql N'DECLARE @i INT; 
                     SELECT @i = OrderID
                     FROM OrdersBig
                     WHERE EmployeeID = @EmployeeID', 
                   N'@EmployeeID INT', 
                    @EmployeeID = 43929
GO

-- This is...
EXEC sp_executesql N'SELECT OrderID
                     FROM OrdersBig
                     WHERE EmployeeID = @EmployeeID', 
                   N'@EmployeeID INT', 
                    @EmployeeID = 43929
GO

-- This is NOT...
-- parameter_sensitive_plan_optimization_skipped_reason = SystemDB
-- be carefull withh linked servers (queries will run from default user db scope)
EXEC master.dbo.sp_executesql N'SELECT OrderID
                                FROM Northwind.dbo.OrdersBig
                                WHERE EmployeeID = @EmployeeID', 
                              N'@EmployeeID INT', 
                               @EmployeeID = 43929
GO

-- This is NOT...
-- parameter_sensitive_plan_optimization_skipped_reason = UnsupportedStatementType
BEGIN TRAN
EXEC sp_executesql N'DELETE
                     FROM OrdersBig
                     WHERE EmployeeID = @EmployeeID', 
                   N'@EmployeeID INT', 
                    @EmployeeID = 43929
ROLLBACK TRAN
GO
-- This is NOT...
-- parameter_sensitive_plan_optimization_skipped_reason = UnsupportedStatementType
EXEC sp_executesql N'SELECT OrderID
                     INTO #tmp1
                     FROM OrdersBig
                     WHERE EmployeeID = @EmployeeID', 
                   N'@EmployeeID INT', 
                    @EmployeeID = 43929
GO
-- This is NOT...
-- parameter_sensitive_plan_optimization_skipped_reason = UnsupportedStatementType
EXEC sp_executesql N'CREATE TABLE #tmp1 (OrderID INT);
                     INSERT INTO #tmp1
                     SELECT OrderID
                     FROM OrdersBig
                     WHERE EmployeeID = @EmployeeID;
                     SELECT * FROM #tmp1;', 
                   N'@EmployeeID INT', 
                    @EmployeeID = 43929
GO



/*
  Scripts

DBCC SHOW_STATISTICS(OrdersBig, ixEmployeeID)
GO
-- Or using sys.dm_db_stats_histogram...
SELECT
  sh.* 
FROM
  sys.stats AS s
CROSS APPLY
  sys.dm_db_stats_histogram(s.object_id, s.stats_id) AS sh
WHERE
  (name = 'ixEmployeeID')
  AND (s.object_id = OBJECT_ID('OrdersBig'));
GO

SELECT ABS(CONVERT(INT, CRYPT_GEN_RANDOM(4) % 5))
*/